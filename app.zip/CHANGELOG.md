
## [0.0.2] 2021-07-04
### Fixes

- Patch #1 - [ImportError: cannot import name 'safe_str_cmp' from 'werkzeug.security'](https://blog.appseed.us/how-to-fix-cannot-import-safe_str_cmp-from-werkzeug/)
  - Freeze `Werkzeug==2.0.3`

## [0.0.1] 2020-09-27
### Initial Release

- Implement `session-based` authentication via Flask-Login
- UI: `Bootstrap5` via CDN
